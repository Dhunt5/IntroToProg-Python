# -------------------------------------------------#
# Title: Working with Classes and Functions/Methods
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   dhunt, 2/22/2018, Added code to complete assignment 5
#   dhunt, 3/1/2018, Updated to use functions/classes; Assignment 6
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# ------- Data --------#
objFileName = "C:\_PythonClass\Todo.txt"
objFile = open(objFileName, "r")
strData = ""
dicTable = {}
lstTable = []
strTask = () # ToDo (key) to add
strPrty = () # Priority (value) to add
strRemove = () # Task to delete

# ------- /Data--------#

# ------Input/Output------#
class IO:
    def DisplayMenu():
        # Displays menu choices to the user
        # Return: strChoice
        print("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)

    @staticmethod
    def InputMenuChoice():
        # Get menu choice from the user
        # return: strChoice
        strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
        return strChoice
    # End Function

    @staticmethod
    def inputTaskAdd():
        # Add a new task
        # Return: tuple of strings (Task,Priority)
        print()
        strAdd = input("What task would you like to add?: ")
        strPrty = input("\nWhat is the priority for this task?: ")
        return strAdd, strPrty
    # End Function

    def SaveDictionaryData(FileName, lstTable):
        objFile = open(objFileName, "w")
        for dicRow in lstTable:
            objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
        objFile.close()
        print("Saved")
    # End Function

    def DisplayTasks(lstTable):
        # Prints current dictionary population
        # Returns: None
        print() #Just adding a line for readability
        print("Printing current data:" + "\n")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print() #Adding another line
# End Function
# End Class
# ------/Input/Output------#

# ----------------Processing----------------------#
class processing:
    @staticmethod
    def LoadDataFromFile():
        # At program start, load data from file to python dictionary #
    	# Return: None
        objFile=open(objFileName,"r")
        for line in objFile:
            lstData = line.split(",") # Read line uses split function to separate the data into two elements
            dicTable = {"Task":lstData[0].strip(), "Priority":lstData[1].strip()}
            lstTable.append(dicTable)
    objFile.close()
    # End function

    @staticmethod
    def InsertTask(strTask, strPrty, lstTable):
        # Add a new task
        # Return: tuple of strings (Task,Priority)
        dicRow = {"Task":strAdd,"Priority":strPrty}
        lstTable.append(dicRow)
    # End Function

'''
This method didn't work
    @staticmethod
    def DeleteTask(strRemove, lstTable):
        # Process remove task request
        # Return: tuple of strings (Task,Priority)
           print()
        strRemove = input("What task would you like to delete?: ")
        if (strRemove in dicTable):
            del dicTable[strRemove]
            for strKey, strValue in dicTable.items():
                print(strKey + ',' + strValue)
        return
    # End Function
    

This statement didn't work 
    @staticmethod
    def inputTaskDel():
        # Remove a task
        # Return: None
        print()
        strRemove = input("What task would you like to delete?: ")
        return strRemove
    # End Function

'''


# End Class
# ----------------/Processing----------------------#

# ----------------Main----------------------------#
# Execute function to load data
processing.LoadDataFromFile()

# Execute function to display menu for user and ask for input
while (True):
    IO.DisplayMenu()
    strChoice = IO.InputMenuChoice()

    # If choice is one, execute function to display current
    if (strChoice.strip() == '1'):
        IO.DisplayTasks(lstTable)
        continue

    # If choice is two, execute function to add a task
    elif (strChoice.strip() == '2'):
        # Ask for task and priority
        strAdd, strPrty = IO.inputTaskAdd()
        processing.InsertTask(strAdd, strPrty, lstTable)
        IO.DisplayTasks(lstTable)
        continue

    elif (strChoice.strip() == '3'):
        # Display current task list
        IO.DisplayTasks(lstTable)
#        # Ask which task to be removed
#        strRemove = processing.DeleteTask()
#        blnStatus = processing.DeleteTask(strRemove, lstTable)
#        IO.DisplayTasks(lstTable)
        strRemove = input("What task would you like to delete?: ")
        if (strRemove in lstTable):
            del lstTable[strRemove]
        IO.DisplayTasks
        continue

    elif (strChoice.strip() == '4'):
        # Save dictionary data to file
        IO.SaveDictionaryData(objFile, lstTable)
        continue

    elif (strChoice.strip() == '5'):
        print("Good bye")
        break  # and Exit the program
        exit()

# ----------------/Main----------------------#
